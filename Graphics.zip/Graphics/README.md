# COMPUTER-GRAPHICS-
simplegraphics algorithm
